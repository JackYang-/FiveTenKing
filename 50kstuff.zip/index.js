var app = require('express')();
var fs = require('fs');
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

/*
 * Application code
*/
//var numPlayers = 0;
var currentUserData = fs.readFileSync("registeredPlayers.json", "utf8");
var players = null;
if (currentUserData)
{
	players = JSON.parse(currentUserData).players;
	for (var i in players.players)
	{
		console.log('checking loaded players: ' + players[i].name + ' ' + players[i].ip);
	}
}
else
{
	players = {};
}

io.on('connection', function(socket){
	var playerIP = socket.handshake.address;
	var playerName = getPlayerName(playerIP);
	if (playerName != "__PLAYERNAMENOTFOUND")
	{
		console.log(playerName + ' has connected');
		socket.emit('set-name', playerName + ' <span class="caret"></a>');
		socket.emit('log-message', 'Welcome back, ' + playerName + '.');
		socket.emit('log-message', 'Currently, ' + players.length + ' player(s) are online');
	}
	else
	{
		players.push({name: "UnamedPlayer", ip:playerIP});
		console.log('a new player connected from ' + playerIP);
		socket.emit('set-name', 'Click me! <span class="caret"></a>');
		socket.emit('log-message', 'Hi there! To get started, give yourself a new name by editing your profile information in the top right dropdown.');
		socket.emit('log-message', 'If this is your first time, please refer to the rule book in the top bar.');
	}
	
	socket.on('disconnect', function () {
		console.log('the player at ' + playerIP + ' disconnected');
	});
	socket.on('set-new-name', function(newName) {
		if (setPlayerName(playerIP, newName))
		{
			socket.emit('set-name', escapeHtml(newName) + ' <span class="caret"></a>');
		}
		else
		{
			socket.emit('log-message', 'An error occurred while changing your name.');
		}
		
	});
});

function escapeHtml(text) {
  var map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };

  return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function setPlayerName (ip, name)
{
	for (var i in players)
	{
		if (players[i].ip == ip)
		{
			players[i].name = name;
			return true;
		}
	}
	return false;
}

function getPlayerName (ip)
{
	for (var i in players)
	{
		if (players[i].ip == ip)
		{
			return players[i].name;
		}
	}
	return "__PLAYERNAMENOTFOUND";
}

http.listen(3000, '10.4.3.177', function(){
  console.log('listening on *:3000');
});